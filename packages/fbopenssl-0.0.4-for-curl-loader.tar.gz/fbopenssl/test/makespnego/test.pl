#!/usr/bin/perl -w

# ------------------------------------------------------------------------------
# test.pl tests makespnego.
#
# Author: Frank Balluffi
#
# Copyright (C) 2002-2005 Frank Balluffi. All rights reserved.
# ------------------------------------------------------------------------------

system "SunOS-release/makespnego init 1.2.840.113554.1.2.2 ../tokens/kerberos-req.der ../temp/spnego-req.der";
system "SunOS-release/makespnego targ 0 1.2.840.113554.1.2.2 ../tokens/kerberos-rep.der ../temp/spnego-rep.der";
exit 0;
