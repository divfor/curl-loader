#!/usr/bin/perl -w

# ------------------------------------------------------------------------------
# test.pl tests parsespnego.
#
# Author: Frank Balluffi
#
# Copyright (C) 2002-2005 Frank Balluffi. All rights reserved.
# ------------------------------------------------------------------------------

system "SunOS-release/parsespnego init ../tokens/spnego-req.der 1.2.840.113554.1.2.2 ../temp/kerberos-req.der";
system "SunOS-release/parsespnego targ ../tokens/spnego-rep.der ../temp/kerberos-rep.der";
exit 0;
