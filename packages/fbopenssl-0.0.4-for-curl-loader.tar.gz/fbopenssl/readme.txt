--------------------------------------------------------------------------------
readme.txt is the read-me file for fbopenssl.

Author: Frank Balluffi

Copyright (C) 2002-2005 Frank Balluffi. All rights reserved.
--------------------------------------------------------------------------------

fbopenssl

Frank Balluffi
April 14, 2005

1 Introduction

fbopenssl is a library containing extensions to OpenSSL, including support for:

- GSS-API (RFC 2743)
- SPNEGO (RFC 2478)

fbopenssl requires the following:

- OpenSSL 0.9.7b or later
- ActiveState ActivePerl 5.8 or later

fbopenssl has been built and tested on the following operating systems:

- Microsoft Windows 2000 with Visual C++ .NET
- Sun Solaris 2.8 (SunOS 5.8) with gcc 2.95
- SuSE Linux 8.2 with gcc 3.3

2 Building fbopenssl

2.1 Linux and UNIX

Build OpenSSL.
Define the environment variable OPENSSLDIR to point to OpenSSL. For example:

echo $OPENSSLDIR
/home/ballfra/external/openssl-0.9.7b

If OpenSSL has been installed, change the following line in Makefile from:

SSLLIB = -Wl,-R$(OPENSSLDIR) -L$(OPENSSLDIR) -lcrypto

to:

SSLLIB = -Wl,-R$(OPENSSLDIR)/lib -L$(OPENSSLDIR)/lib -lcrypto

cd fbopenssl
gmake CFG=debug
gmake CFG=release
cd test/makespnego
gmake CFG=debug
gmake CFG=release
cd ../parsespnego
gmake CFG=debug
gmake CFG=release

2.2 Windows

Build OpenSSL.
Define the environment variable OPENSSLDIR to point to OpenSSL. For example:

echo %OPENSSLDIR%
C:\external\openssl-0.9.7b

Using Visual C++ .NET, build the following Win32 Debug and Win32 Release
configurations:

fbopenssl\fbopenssl.sln
fbopenssl\test\makespnego\makespnego.sln
fbopenssl\test\parsespnego\parsespnego.sln

3 Testing fbopenssl

3.1 Linux and UNIX

cd fbopenssl/test/makespnego
./test.pl
cd ../parsespnego
./test.pl

3.2 Windows

cd fbopenssl\test\makespnego
test.pl
cd ..\parsespnego
test.pl

4 Open Issues

Ask the authors of RFC 2478 about the use of EXPLICIT tagging and underscores in
element names.

IE sends the SPNEGO mechanism types 1.2.840.48018.1.2.2, 1.2.840.113554.1.2.2
and 1.3.6.1.4.1.311.2.2.10. www.google.com finds the following about
1.3.6.1.4.1.311.2.2.10:

"To be honest, I'm more interested in getting a working SPNEGO implementation
that just negotiates Kerberos V than mechglue, but once we have the latter done,
it should be quite trivial to wrap up dcerpc.net's NTLMSSP library as a GSS-API
mechanism (Microsoft use OID 1.3.6.1.4.1.311.2.2.10 for this, FWIW)."

and

"The NTLM stuff is advertised as an SNEGO sub-mechanism OID -
.1.3.6.1.4.1.311.2.2.10
(.iso.org.dod.internet.private.enterprises.microsoft.2.2.10). The actual
contents of the SNEGO packets are the ordinary NTLM auth exchanges, prefixed
with the ASCII test "NTLMSSP" (a "distinct OID" in Microsoft's words... <pfff>
yeah, right)."

Should fbopenssl library define 1.3.6.1.4.1.311.2.2.10?

What is the difference between ASN1_BIT_STRING_new, ASN1_ENUMERATED_new and
ASN1_OCTET_STRING, and M_ASN1_BIT_STRING_new, M_ASN1_ENUMERATED_new and
M_ASN1_OCTET_STRING_new?

Is it possible to add GSS-API and SPNEGO function and reason error strings
without modifying OpenSSL? If no, how should spnegohelp.c functions return error
information to its callers?

Test the test utilities fbopenssl/test/makespnego and fbopenssl/test/parsespnego
with Purify.

parseSpnegoInitialToken and parseSpnegoTargetToken return an error if a caller
requests an optional element that is not present. Is this desirable?
