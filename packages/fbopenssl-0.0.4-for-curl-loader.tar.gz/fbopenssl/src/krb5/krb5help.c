/* -----------------------------------------------------------------------------
 * krb5help.c defines Kerberos version 5 helper APIs.
 *
 * Author: Frank Balluffi
 *
 * Copyright (C) 2002-2005 Frank Balluffi. All rights reserved.
 * -----------------------------------------------------------------------------
 */

#include "../../include/krb5help.h"

/* Object identifier definitions. */

static unsigned char _krb5GssApi []         = {0x2a, 0x86, 0x48, 0x86, 0xf7, 0x12, 0x01, 0x02, 0x02};
static unsigned char _msKrb5GssApiLegacy [] = {0x2a, 0x86, 0x48, 0x82, 0xf7, 0x12, 0x01, 0x02, 0x02};

const ASN1_OBJECT krb5GssApi         = {0, 0, 0, sizeof _krb5GssApi,         _krb5GssApi,         0};
const ASN1_OBJECT msKrb5GssApiLegacy = {0, 0, 0, sizeof _msKrb5GssApiLegacy, _msKrb5GssApiLegacy, 0};
